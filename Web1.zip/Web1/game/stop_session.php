<?php
session_start();

// Clear game-related session data
unset($_SESSION['level']);
unset($_SESSION['lives']);

// Redirect the user to the home page or user dashboard
header('Location: ../index.php');
exit;
?>
