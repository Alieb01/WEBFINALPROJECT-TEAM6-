<?php
session_start();


unset($_SESSION['level']);
unset($_SESSION['lives']);


header('Location: ../index.php');
exit;
?>
