<?php
session_start();
require_once ('../includes/config.php');
require_once ('../includes/functions.php');

if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}

if (!isset($_SESSION['lives'])) {
    $_SESSION['lives'] = 6;
    $_SESSION['level'] = 1;
}

if ($_SESSION['level'] != 2) {
    header('Location: level' . $_SESSION['level'] . '.php');
    exit;
}

$error = '';
$success = false;
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $letters = isset($_POST['letters']) ? (array)$_POST['letters'] : [];
    $original_letters = isset($_POST['original_letters']) ? explode(',', $_POST['original_letters']) : [];

    $result = checkLevel2($original_letters, $letters);
    if ($result === true) {
        $success = true;
        $_SESSION['level'] = 3;
    } else {
        $error = $result;
        $_SESSION['lives'] -= 1;
        if ($_SESSION['lives'] <= 0) {
            header('Location: game_over.php');
            exit;
        }
    }
}

$random_letters_array = generateRandomLetters(6);
$random_letters = implode(', ', $random_letters_array);
$original_letters = implode(',', $random_letters_array);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Level 2</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>Game Level 2: Order Letters in Descending Order</h1>
    </header>

    <main>
        <?php if ($success) : ?>
            <p class="success">Correct! You have ordered the letters correctly in descending order.</p>
            <a href="level3.php">Go to the Next Level</a>
        <?php else : ?>
            <p class="info">Lives left: <?php echo $_SESSION['lives']; ?></p>
            <?php if (!empty($error)) : ?>
                <p class="error"><?php echo $error; ?></p>
            <?php endif; ?>
            <p>Order these letters in descending order:</p>
            <p class="letters"><?php echo implode(' ', $random_letters_array); ?></p>
            <form action="level2.php" method="post">
                <input type="hidden" name="original_letters" value="<?php echo $original_letters; ?>">
                <?php for ($i = 0; $i < 6; $i++) : ?>
                    <input type="text" name="letters[]" maxlength="1" required>
                <?php endfor; ?>
                <br>
                <input type="submit" name="submit" value="Submit">
            </form>
        <?php endif; ?>
        <a href="web1/../signout.php">Sign Out</a>
    </main>

    <footer>
        <p>Developed by Team 6</p>
    </footer>
</body>
</html>
