<?php 

session_start();

/*
if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit;
}
*/
session_destroy();


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Game Over</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>Game Over</h1>
    <p>You have used all your lives. Better luck next time!</p>

    <a href="../index.php?reset=true">Play Again</a>
    <a href="../index.php">Home Page</a>
</body>
</html>
