<?php
session_start();
require_once ('../includes/config.php');
require_once ('../includes/functions.php');

if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}

if (!isset($_SESSION['lives'])) {
    $_SESSION['lives'] = 6;
    $_SESSION['level'] = 1;
}

if ($_SESSION['level'] != 4) {
    header('Location: level' . $_SESSION['level'] . '.php');
    exit;
}

$error = '';
$success = false;
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $numbers = isset($_POST['numbers']) ? (array)$_POST['numbers'] : [];
    $original_numbers = isset($_POST['original_numbers']) ? explode(',', $_POST['original_numbers']) : [];

    $result = checkLevel4($original_numbers, $numbers);
    if ($result === true) {
        $success = true;
        $_SESSION['level'] = 5;
    } else {
        $error = $result;
        $_SESSION['lives'] -= 1;
        if ($_SESSION['lives'] <= 0) {
            header('Location: game_over.php');
            exit;
        }
    }
}

$random_numbers_array = generateRandomNumbers(6);
$original_numbers = implode(',', $random_numbers_array);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Level 4</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>Game Level 4: Order Numbers in Descending Order</h1>
    </header>

    <main>
        <?php if ($success) : ?>
            <p class="success">Correct! You have ordered the numbers correctly in descending order.</p>
            <a href="level5.php">Go to the Next Level</a>
        <?php else : ?>
            <p class="info">Lives left: <?php echo $_SESSION['lives']; ?></p>
            <?php if (!empty($error)) : ?>
                <p class="error"><?php echo $error; ?></p>
            <?php endif; ?>
            <p>Order these numbers in descending order:</p>
            <p class="numbers"><?php echo implode(' ', $random_numbers_array); ?></p>
            <form action="level4.php" method="post">
                <input type="hidden" name="original_numbers" value="<?php echo $original_numbers; ?>">
                <?php for ($i = 0; $i < 6; $i++) : ?>
                    <input type="number" name="numbers[]" min="0" max="100" required>
                <?php endfor; ?>
                <br>
                <input type="submit" name="submit" value="Submit">
            </form>
        <?php endif; ?>
        <a href="web1/../signout.php">Sign Out</a>

    </main>

    <footer>
        <p>Developed by Team 6</p>
    </footer>
</body>
</html>
