<?php
session_start();
require_once ('../includes/config.php');
require_once ('../includes/functions.php');

if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}

if (!isset($_SESSION['lives'])) {
    $_SESSION['lives'] = 6;
    $_SESSION['level'] = 5;
}

if ($_SESSION['level'] != 5) {
    header('Location: level' . $_SESSION['level'] . '.php');
    exit;
}

$error = '';
$success = false;
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first_letter = isset($_POST['first_letter']) ? $_POST['first_letter'] : '';
    $last_letter = isset($_POST['last_letter']) ? $_POST['last_letter'] : '';
    $original_letters = isset($_POST['original_letters']) ? explode(',', $_POST['original_letters']) : [];

    $result = checkLevel5($original_letters, $first_letter, $last_letter);
    if ($result === true) {
        $success = true;
        $_SESSION['level'] = 6;
    } else {
        $error = $result;
        $_SESSION['lives'] -= 1;
        if ($_SESSION['lives'] <= 0) {
            header('Location: game_over.php');
            exit;
        }
    }
}

$random_letters_array = generateRandomLetters(6);
$random_letters = implode(' ', $random_letters_array);
$original_letters = implode(',', $random_letters_array);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Level 5</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>Game Level 5: Identify First and Last Letters from a Set of Letters</h1>
    </header>

    <main>
        <?php if ($success) : ?>
            <p class="success">Correct! You have identified the first and last letters correctly.</p>
            <a href="level6.php">Go to the Next Level</a>
        <?php else : ?>
            <p class="info">Lives left: <?php echo $_SESSION['lives']; ?></p>
            <?php if (!empty($error)) : ?>
                <p class="error"><?php echo $error; ?></p>
            <?php endif; ?>
            <p>Identify the first and last letters from this set of letters:</p>
            <p class="letters"><?php echo $random_letters; ?></p>
            <form action="level5.php" method="post">
                <input type="hidden" name="original_letters" value="<?php echo $original_letters; ?>">
                <label for="first_letter">First Letter:</label>
                <input type="text" name="first_letter" id="first_letter" maxlength="1" required>
                <label for="last_letter">Last Letter:</label>
                <input type="text" name="last_letter" id="last_letter" maxlength="1" required>
                <br>
                <input type="submit" name="submit" value="Submit">
            </form>
        <?php endif; ?>
        <a href="web1/../signout.php">Sign Out</a>
        <a href="../history.php">History</a>

    </main>

    <footer>
        <p>Developed by Team 7</p>
    </footer>
</body>
</html>
