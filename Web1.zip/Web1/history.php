<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Game History</title>
    <!-- Add your CSS file here -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>Game History</h1>
    </header>
    <nav>
        <!-- Your navigation menu items here -->
    </nav>
    <article>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Result</th>
                    <th>Lives Used</th>
                    <th>Date/Time</th>
                </tr>
            </thead>
            <tbody> 
                <?php 
                $historyData = getGameHistory($pdo);

                foreach ($historyData as $row) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['id']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['first_name']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['last_name']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['result']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['lives_used']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['date_time']) . "</td>";
                    echo "</tr>";
                } 
                ?> 
            </tbody>
        </table>
    </article>
    <footer>
        <!-- Your footer content here -->
    </footer>
</body>
</html>
