<?php
session_start();
require_once 'includes/config.php';
require_once 'includes/functions.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Game History</title>

    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>Game History</h1>
    </header>
    <nav>
        
    </nav>
    <article>
        <table>
            <thead>
            <tr>
                <th>User</th>
                <th>ID</th>
                <th>Result</th>
                <th>Lives Used</th>
                <th>Date/Time</th>
            </tr>
            </thead>
            <tbody> 
                <?php 
                $historyData = getGameHistory($pdo);

                foreach ($historyData as $row) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['id']) . "</td>"; 
                    echo "<td>" . htmlspecialchars($row['user_id']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['result']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['lives_used']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['date_time']) . "</td>";
                    echo "</tr>";
                } 
                ?> 
                
            </tbody>
        </table>
    </article>
    <footer>
    <a href="game/signout.php">Sign Out</a>
    <a href="web1/../index.php">Go Back</a>
        <p>Developed by Team 7</p>
    </footer>
</body>
</html>
