<?php
session_start();
require_once 'includes/config.php';
require_once 'includes/functions.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']); 
    $current_password = trim($_POST['current_password']);
    $new_password = trim($_POST['new_password']);
    $confirm_new_password = trim($_POST['confirm_new_password']);

    $error = updatePassword($username, $current_password, $new_password, $confirm_new_password);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Password Modification</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>A kid's Games</h1>
    </header>

    <main>
        <h2>Password Modification</h2>
        <?php if (!empty($error)) : ?>
            <p class="error"><?php echo $error; ?></p>
        <?php endif; ?>
        <form action="password_modification.php" method="post">
            <label for="username">Username:</label> 
            <input type="text" name="username" id="username" required> 
            <br>
            <label for="current_password">Current Password:</label>
            <input type="password" name="current_password" id="current_password" required>
            <br>
            <label for="new_password">New Password:</label>
            <input type="password" name="new_password" id="new_password" required>
            <br>
            <label for="confirm_new_password">Confirm New Password:</label>
            <input type="password" name="confirm_new_password" id="confirm_new_password" required>
            <br>
            <input type="submit" name="submit" value="Update Password">
            <a href="index.php">Login</a>
        </form>
    </main>

    <footer>
        <p>Developed by Team 6</p>
    </footer>
</body>
</html>