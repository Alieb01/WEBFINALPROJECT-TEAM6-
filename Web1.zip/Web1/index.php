<?php
session_start();
require_once 'includes/config.php';
require_once 'includes/functions.php';

if (isset($_GET['reset']) && $_GET['reset'] == 'true') {
    $_SESSION['lives'] = 6;
    $_SESSION['level'] = 1;
}

if (isset($_GET['signout']) && $_GET['signout'] == 'true') {
    session_start();
    session_unset();
    session_destroy();
    header('Location: index.php');
    exit;
}


if (isset($_SESSION['username']) && !isset($_GET['signout'])) {
    header('Location: game/level1.php');
    exit;
}



$error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    $error = loginUser($username, $password);


    if (empty($error)) {
        header('Location: game/level1.php');
        exit;
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>A kid's Game</h1>
    </header>

    <main>
        <h2>Login</h2>
        <?php if (!empty($error)) : ?>
            <p class="error"><?php echo $error; ?></p>
        <?php endif; ?>
        <form action="index.php" method="post">
            <label for="username">Username:</label>
            <input type="text" name="username" id="username" required>
            <br>
            <label for="password">Password:</label>
            <input type="password" name="password" id="password" required>
            <br>
            <input type="submit" name="submit" value="Connect">
            <a href="registration.php">Sign-Up</a>
            <a href="password_modification.php">Change Password</a>
        </form>
    </main>

    <footer>
        <p>Developed by Team 7</p>
    </footer>
</body>
</html>
