<?php
require_once 'includes/config.php';

class User {
    private $id;
    private $username;
    private $password;
    private $firstName;
    private $lastName;

    public function __construct($id, $username, $password, $firstName, $lastName) {
        $this->id = $id;
        $this->username = $username;
        $this->password = $password;
        $this->firstName = $firstName;
        $this->lastName = $lastName;
    }

    public function register() {
        global $pdo;

        $query = "INSERT INTO users (username, password, first_name, last_name) VALUES (:username, :password, :firstName, :lastName)";
        $statement = $pdo->prepare($query);

        $statement->bindParam(':username', $this->username);
        $statement->bindParam(':password', $this->password);
        $statement->bindParam(':firstName', $this->firstName);
        $statement->bindParam(':lastName', $this->lastName);

        return $statement->execute();
    }

    public function login() {
        global $pdo;

        $query = "SELECT * FROM users WHERE username = :username";
        $statement = $pdo->prepare($query);
        $statement->bindParam(':username', $this->username);
        $statement->execute();

        $user = $statement->fetch(PDO::FETCH_ASSOC);
        if ($user && password_verify($this->password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            return true;
        } else {
            return false;
        }
    }

    public function logout() {
        unset($_SESSION['user_id']);
        session_destroy();
    }

    public function modifyPassword($newPassword) {
        global $pdo;

        $query = "UPDATE users SET password = :password WHERE id = :id";
        $statement = $pdo->prepare($query);
        $statement->bindParam(':password', $newPassword);
        $statement->bindParam(':id', $this->id);

        return $statement->execute();
    }

    public function getGameHistory() {
        global $pdo;

        $query = "SELECT * FROM game_history WHERE user_id = :id";
        $statement = $pdo->prepare($query);
        $statement->bindParam(':id', $this->id);
        $statement->execute();

        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
