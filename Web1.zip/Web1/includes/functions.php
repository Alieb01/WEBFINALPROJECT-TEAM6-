<?php
require_once 'config.php';

function connectToDatabase()
{

    $host = 'localhost';
    $db_name = 'game2_db';
    $username = 'root';
    $password = '';

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}


function registerUser($username, $password, $confirm_password) {
    global $pdo;

    if ($password != $confirm_password) {
        return 'Passwords do not match.';
    }

    $stmt = $pdo->prepare("SELECT * FROM auth WHERE username = :username");
    $stmt->execute([':username' => $username]);
    if ($stmt->rowCount() > 0) {
        return 'Username already exists.';
    }

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO auth (username, password) VALUES (:username, :password)");
    $stmt->execute([':username' => $username, ':password' => $hashed_password]);

    return '';
}


function loginUser($username, $password) {
    global $pdo;

    $stmt = $pdo->prepare("SELECT * FROM auth WHERE username = :username");
    $stmt->execute([':username' => $username]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password'])) {
        return 'Invalid username or password.';
    }


    $_SESSION['username'] = $user['username'];

    return '';
}

function updatePassword($username, $current_password, $new_password, $confirm_new_password) {
    global $pdo;

    if ($new_password != $confirm_new_password) {
        return 'New passwords do not match.';
    }

    $stmt = $pdo->prepare("SELECT * FROM auth WHERE username = :username");
    $stmt->execute([':username' => $username]);
    $user = $stmt->fetch();

    if (!password_verify($current_password, $user['password'])) {
        return 'Current password is incorrect.';
    }

    $hashed_new_password = password_hash($new_password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("UPDATE auth SET password = :password WHERE username = :username");
    $stmt->execute([':username' => $username, ':password' => $hashed_new_password]);

    return '';
}

function getGameHistory($pdo)
{
    try {
        $stmt = $pdo->prepare("SELECT * FROM game_history");
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
function generateRandomLetters($count) {
    $letters = range('a', 'z');
    shuffle($letters);
    return array_slice($letters, 0, $count);
}

function checkLevel1($original_letters, $submitted_letters) {
    if (count(array_diff($original_letters, $submitted_letters)) > 0) {
        return "Incorrect - Some of your letters are different from ours";
    }
    $ordered_letters = $original_letters;
    sort($ordered_letters);
    if ($ordered_letters === $submitted_letters) {
        return true;
    }
    return "Incorrect - Your letters have not been correctly ordered in ascending order";
}

function checkLevel2($original_letters, $user_letters) {
    if (count($original_letters) != count($user_letters)) {
        return "Incorrect input. Please enter exactly 6 letters.";
    }

    foreach ($user_letters as $letter) {
        if (!in_array($letter, $original_letters)) {
            return "Some of your letters are different than ours.";
        }
    }

    $sorted_original_letters = $original_letters;
    rsort($sorted_original_letters);

    if ($sorted_original_letters === $user_letters) {
        return true;
    }

    return "Incorrect - Your letters have not been correctly ordered in descending order.";
}

function generateRandomNumbers($count) {
    $numbers = range(0, 100);
    shuffle($numbers);
    return array_slice($numbers, 0, $count);
}

function checkLevel3($original_numbers, $user_numbers) {
    if (count(array_diff($original_numbers, $user_numbers)) > 0) {
        return "Incorrect - Some of your numbers are different than ours";
    }

    $sorted_numbers = $original_numbers;
    sort($sorted_numbers);
    if ($sorted_numbers === $user_numbers) {
        return true;
    } else {
        return "Incorrect - Your numbers have not been correctly ordered in ascending order";
    }
}

function checkLevel4($original_numbers, $user_numbers) {
    if (count(array_diff($original_numbers, $user_numbers)) > 0) {
        return 'Incorrect - Some of your numbers are different than ours';
    }

    $sorted_numbers = $user_numbers;
    rsort($sorted_numbers);

    if ($sorted_numbers === $user_numbers) {
        return true;
    } else {
        return 'Incorrect - Your numbers have not been correctly ordered in descending order';
    }
}

function generateRandomLettersWithFirstLast($count) {
    $letters = range('a', 'z');
    shuffle($letters);
    return array_slice($letters, 0, $count);
}

function checkLevel5($original_letters, $first_letter, $last_letter) {
    $first_original = min($original_letters);
    $last_original = max($original_letters);

    if ($first_original === $first_letter && $last_original === $last_letter) {
        return true;
    } else {
        return 'Incorrect - The first and last letters do not match the original letters.';
    }
}


function checkLevel6($original_numbers, $min_number, $max_number) {
    $min_original = min($original_numbers);
    $max_original = max($original_numbers);

    if ($min_number == $min_original && $max_number == $max_original) {
        return true;
    }

    return "Incorrect - The minimum and maximum numbers you entered are not correct.";
}



?>
